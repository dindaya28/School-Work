Please see Java files are located within src directory
